package ss.week2.hotel;

public class Safe {
	private boolean isActiveVar;
	private boolean isOpenVar;
	
	public Password pass = new Password();
	
	public Safe(String newpass){
		pass.setWord("Password123",newpass);
	}
	
	public void activate(String trypass) {
		if(!pass.testWord(trypass)) System.out.println("Wrong Password!");
		isActiveVar = pass.testWord(trypass);
		System.out.println(isActiveVar);
	}
	
	public void deactivate() {
		if(isActiveVar) isActiveVar = false;
		else System.out.println("The Safe isn't activated!");
		System.out.println(isActiveVar);
	}
	
	public void open(String trypass) {
		if(!pass.testWord(trypass)) System.out.println("Wrong Password!");
		isOpenVar = pass.testWord(trypass);
		System.out.println(isOpenVar);
	}
	
	public void close() {
		if(isOpenVar) isOpenVar = false;
		System.out.println(isOpenVar);
	}
	
	public boolean isActive() { return isActiveVar; }
	
	public boolean isOpen() { return isOpenVar; }
	
	public Password getPassWord() {
		return pass;
	}
}