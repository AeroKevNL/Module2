package ss.week2.hotel;

public class Safe {

}
