package ss.week1.hotel;

/** 
 * Hotel guest with a name and possibly a hotel room.
 * @author Tim Sonderen & Kevin Hetterscheid
 * @version $Revision: 0.0.4 $
 */
public class Guest {
	
	String guestName;
	Room roomNumber;
	
	public Guest(java.lang.String n){
		this.guestName = n;
	}
	
	public boolean checkin(ss.week1.hotel.Room r){
		if(getRoom() == null || r.getGuest() != null){
			roomNumber = r;
			r.setGuest(this);
			return true;
		}
		else return false;
	}
	
	public boolean checkout(){
		if(roomNumber == null){
			return false;
		}
		else {
			roomNumber.setGuest(null);
			roomNumber = null;
			return true;
		}
	}
	
	public String getName() {
		return guestName;
	}
	
	public Room getRoom() {
		return roomNumber;
	}
}
