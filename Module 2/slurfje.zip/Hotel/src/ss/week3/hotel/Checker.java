package ss.week3.hotel;

public interface Checker {
	public boolean acceptable(String pass);
	public String generatePass();
}