package ss.week3.hotel;

public class Ite implements Item {
	
	public double getAmount(){
		return 1.00;
	}
}
