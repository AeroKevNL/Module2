package ss.week3.hotel;

public class Tester {

	public static void main(String[] args) {
		Format.printLine("textdsa1", 1.25);
		Format.printLine("text2da", 124.13);
		Format.printLine("text3", -14.65);
		Format.printLine("tesaxt4", 5.83);
	}

}
