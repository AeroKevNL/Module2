package ss.week3.hotel;

public interface Item {
	public double getAmount();
}
