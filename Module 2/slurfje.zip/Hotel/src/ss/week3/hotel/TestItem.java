package ss.week3.hotel;

import ss.week3.hotel.Format;

public class TestItem implements Bill.Item {
        private String description;
        private double amount;
        
        public TestItem(String description, double amount) {
                this.description = description;
                this.amount = amount;
        }
        
        public String toString() {
                return Format.printLine(description, getAmount());
        }

        public double getAmount() {
                return amount;
        }
}