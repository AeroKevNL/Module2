package ss.week1;

/**
 * Hello World class.
 * @author Arend Rensink
 */
public class Hello {
    /**
     * @param args command-line arguments; currently unused
     */
    public static void main(String[] args) {
        System.out.println("Hello, world!");
    }
}